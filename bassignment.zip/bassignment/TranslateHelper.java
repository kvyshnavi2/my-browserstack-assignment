package bassignment;

import java.util.*;
import org.openqa.selenium.*;

public class TranslateHelper {

    public static String translateViaGoogle(WebDriver driver, String text) {
        driver.get("https://translate.google.com/");
        WebElement input = driver.findElement(By.xpath("//textarea[@aria-label='Source text']"));
        input.clear();
        input.sendKeys(text);

        // Wait for translation to appear
        try {
            Thread.sleep(3000);  // Replace with WebDriverWait in real project
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement translatedOutput = driver.findElement(By.xpath("//span[@jsname='W297wb']"));
        return translatedOutput.getText();
    }

    public static void analyzeTranslatedHeaders(List<String> headers) {
        Map<String, Integer> wordCount = new HashMap<>();

        for (String header : headers) {
            String[] words = header.toLowerCase().split("\\W+");
            for (String word : words) {
                if (!word.isBlank()) {
                    wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
                }
            }
        }

        System.out.println("\n🔍 Repeated Words (Appeared more than twice):");
        boolean found = false;
        for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
            if (entry.getValue() > 2) {
                System.out.println("  👉 " + entry.getKey() + ": " + entry.getValue());
                found = true;
            }
        }

        if (!found) {
            System.out.println("✅ No words repeated more than twice.");
        }
    }
}
