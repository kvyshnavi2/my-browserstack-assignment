package bassignment;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.io.*;
import java.net.*;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class Assignment {

    public static void main(String[] args) throws Exception {

        // Set ChromeDriver path
        System.setProperty("web.driver.chromedriver", "C:/Users/kothapalli vyshnavi/Documents/chrome-win64/chromedriver.exe");

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        
        // 1. Open El País
        driver.get("https://elpais.com/");

        // 2. Click on 'Opinión' section
     // STEP 2: Navigate to the Opinion section
        try {
            driver.get("https://elpais.com");

            // ✅ Handle cookie popup first
            try {
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                WebElement acceptBtn = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[normalize-space()='Accept' or contains(text(),'Aceptar')]")));
                acceptBtn.click();
                System.out.println("✅ Cookie popup dismissed.");
            } catch (TimeoutException e) {
                System.out.println("⚠️ No cookie popup appeared.");
            }

            // ✅ Then wait for the "Opinión" link and click it
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("blockNavigation")));

            WebElement opinionLink = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//a[@cmp-ltrk='portada_menu' and normalize-space()='Opinión']")));
            opinionLink.click();
            System.out.println("✅ Navigated to Opinión section.");

        } catch (TimeoutException e) {
            System.out.println("⚠️ Overlay didn't disappear, trying JS click...");

            WebElement opinionLink = driver.findElement(
                By.xpath("//a[@cmp-ltrk='portada_menu' and normalize-space()='Opinión']"));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", opinionLink);

            System.out.println("✅ Navigated to Opinión section via JavaScript click.");
        }


        // 3. Wait a bit for articles to load
        Thread.sleep(3000);

        // 4. Find and loop through the first 5 articles
        List<WebElement> articles = driver.findElements(By.xpath("//article"));

        int count = 0;
        for (WebElement article : articles) {
            if (count >= 5) break;

            try {
                // Get title
                WebElement titleEl = article.findElement(By.tagName("h2"));
                String title = titleEl.getText().trim();
                if (title.isEmpty()) continue;
                System.out.println("\n📌 Title: " + title);

                // Get content/summary
                WebElement paraEl = article.findElement(By.tagName("p"));
                String content = paraEl.getText().trim();
                if (content.isEmpty()) continue;
                System.out.println("📄 Content: " + content);

                // Get image (if available)
                List<WebElement> imgs = article.findElements(By.tagName("img"));
                if (!imgs.isEmpty()) {
                    String imgUrl = imgs.get(0).getAttribute("src");
                    System.out.println("🖼️ Image URL: " + imgUrl);

                    // Save image
                    saveImage(imgUrl, "article_" + (count + 1) + ".jpg");
                }

                count++;
            } catch (Exception e) {
                System.out.println("⚠️ Skipping article due to missing elements: " + e.getMessage());
            }
        }

        driver.quit();
    }

    // Helper method to download image
    public static void saveImage(String imageUrl, String fileName) {
        try (InputStream in = new URL(imageUrl).openStream();
             FileOutputStream out = new FileOutputStream("C:\\Users\\kothapalli vyshnavi\\Downloads\\ElPaisImages" + fileName)) {
            byte[] buffer = new byte[2048];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
            System.out.println("✅ Image saved: " + fileName);
        } catch (IOException e) {
            System.out.println("❌ Failed to save image: " + e.getMessage());
        }
    }
}
