package bassignment;

import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Translate {

    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        try {
            driver.get("https://elpais.com/opinion/");

            // Step 1: Get all article titles (as Strings, not WebElements)
            List<WebElement> titleElements = driver.findElements(By.cssSelector("article h2 a"));
            List<String> titles = new ArrayList<>();

            for (WebElement element : titleElements) {
                titles.add(element.getText().trim());
            }

            System.out.println("\n💡 Translating top 5 titles to English via Google Translate...");
            System.out.println("📰 Total titles found: " + titles.size() + "\n");

            List<String> translatedTitles = new ArrayList<>();

            for (int i = 0; i < Math.min(5, titles.size()); i++) {
                String original = titles.get(i);
                System.out.println("🔹 Original: " + original);

                try {
                    String translated = TranslateHelper.translateViaGoogle(driver, original);
                    translatedTitles.add(translated);
                    System.out.println("🔸 Translated: " + translated);
                } catch (Exception e) {
                    System.out.println("⚠️ Skipping stale element.");
                }
            }

            // Step 4: Analyze repeated words
            TranslateHelper.analyzeTranslatedHeaders(translatedTitles);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}
