package bassignment;

import java.util.*;

public class HeaderAnalyzer {
    public static void analyzeTranslatedHeaders(List<String> translatedHeaders) {
        Map<String, Integer> wordCount = new HashMap<>();

        for (String header : translatedHeaders) {
            String[] words = header.toLowerCase().replaceAll("[^a-z ]", "").split("\\s+");

            for (String word : words) {
                if (!word.isEmpty()) {
                    wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
                }
            }
        }

        System.out.println("\n🔍 Repeated Words (Appeared more than twice):");
        boolean found = false;
        for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
            if (entry.getValue() > 2) {
                found = true;
                System.out.println("🔁 Word: '" + entry.getKey() + "' → Count: " + entry.getValue());
            }
        }

        if (!found) {
            System.out.println("✅ No words repeated more than twice.");
        }
    }
}
